#include <ns3/src-header.h>

int
main()
{
    testPrint2();
    return 0;
}
