
NSNAM_CODE_BASE_URL = "https://gitlab.com/nsnam/ns-3-dev.git"

# NetAnim
NETANIM_REPO = "https://gitlab.com/nsnam/netanim.git"
NETANIM_RELEASE_URL = "https://gitlab.com/nsnam/netanim/-/archive"

LOCAL_NETANIM_PATH = "netanim"

# bake
BAKE_REPO = "https://gitlab.com/nsnam/bake.git"
