#ifndef NS3_SRC_SOURCE2_H
#define NS3_SRC_SOURCE2_H

void testPrint2();

#endif // NS3_SOURCE_H
