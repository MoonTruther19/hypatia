#include <ns3/contrib-header.h>

void
testPrint2()
{
    testPrint();
}
